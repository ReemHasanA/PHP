
<?php
// echo "Warning error";
// include ("external_file.php");
?>

<?php
// $a="Defined error";
// echo "Notice error";
// echo $b;
?>

<?php
// echo "Red";
// echo "Blue"
// echo "Green";
?>

<?php
function sub()
{
$sub=6-1;
echo "The sub= ".$sub;
}
div();
?>