<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="empolyee";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
